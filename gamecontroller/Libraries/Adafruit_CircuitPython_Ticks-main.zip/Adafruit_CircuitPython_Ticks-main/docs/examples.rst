Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ticks_simpletest.py
    :caption: examples/ticks_simpletest.py
    :linenos:
