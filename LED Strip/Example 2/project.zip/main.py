from neopixel import Neopixel
from time import sleep

#setup
NUM_LEDS= 16
LED_PIN = 28
pixels = Neopixel(NUM_LEDS, 0, LED_PIN, "GRB")
#pixels.brightness(255)

#constants
red = pixels.colorHSV(0,255,255)
orange = pixels.colorHSV(30, 255, 128)

#loop
while True:
    for color in [red, orange]:
        print(color)
        pixels.fill(color)
        pixels.show()
        sleep(0.5)